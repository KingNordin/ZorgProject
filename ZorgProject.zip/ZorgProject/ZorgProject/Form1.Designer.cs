﻿
namespace ZorgProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnPatient = new System.Windows.Forms.Button();
            this.BtnDoctor = new System.Windows.Forms.Button();
            this.CbBLanguage = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // BtnPatient
            // 
            this.BtnPatient.Location = new System.Drawing.Point(12, 42);
            this.BtnPatient.Name = "BtnPatient";
            this.BtnPatient.Size = new System.Drawing.Size(201, 69);
            this.BtnPatient.TabIndex = 0;
            this.BtnPatient.Text = "Ik ben een patient";
            this.BtnPatient.UseVisualStyleBackColor = true;
            this.BtnPatient.Click += new System.EventHandler(this.BtnPatient_Click);
            // 
            // BtnDoctor
            // 
            this.BtnDoctor.Location = new System.Drawing.Point(12, 126);
            this.BtnDoctor.Name = "BtnDoctor";
            this.BtnDoctor.Size = new System.Drawing.Size(201, 69);
            this.BtnDoctor.TabIndex = 1;
            this.BtnDoctor.Text = "Ik ben een doctor";
            this.BtnDoctor.UseVisualStyleBackColor = true;
            this.BtnDoctor.Click += new System.EventHandler(this.BtnDoctor_Click);
            // 
            // CbBLanguage
            // 
            this.CbBLanguage.FormattingEnabled = true;
            this.CbBLanguage.Items.AddRange(new object[] {
            "NL",
            "EN"});
            this.CbBLanguage.Location = new System.Drawing.Point(208, 12);
            this.CbBLanguage.Name = "CbBLanguage";
            this.CbBLanguage.Size = new System.Drawing.Size(50, 24);
            this.CbBLanguage.TabIndex = 2;
            this.CbBLanguage.SelectedIndexChanged += new System.EventHandler(this.CbBLanguage_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 216);
            this.Controls.Add(this.CbBLanguage);
            this.Controls.Add(this.BtnDoctor);
            this.Controls.Add(this.BtnPatient);
            this.Name = "Form1";
            this.Text = "Program";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnPatient;
        private System.Windows.Forms.Button BtnDoctor;
        private System.Windows.Forms.ComboBox CbBLanguage;
    }
}

