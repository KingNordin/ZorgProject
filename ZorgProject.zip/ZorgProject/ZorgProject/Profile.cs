﻿using System;

namespace ZorgProject
{
    class Profile
    {
        private string fname;
        private string lname;
        private int age;
        private double weight;
        private double length;

        public Profile(string fname, string lname, int age, double weight, double length)
        {
            this.fname = fname;
            this.lname = lname;
            this.age = age;
            this.weight = weight;
            this.length = length;
        }

        public string FName
        {
            get { return fname; }
            set { fname = value; }
        }

        public string LName
        {
            get { return lname; }
            set { lname = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        }

        public double Lenght
        {
            get { return length; }
            set { length = value; }
        }

        public string BMI()
        {
            return Convert.ToString(Math.Round(this.weight / Math.Pow(this.length, 2) * 100.00) / 100.00);
        }
    }
}
