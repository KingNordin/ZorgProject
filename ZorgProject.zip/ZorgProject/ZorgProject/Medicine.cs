﻿namespace ZorgProject
{
    class Medicine
    {
        private string medicineName;
        private string description;
        private string sort;
        private string dosage;

        public string MedicineName
        {
            get { return medicineName; }
            set { medicineName = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string Sort
        {
            get { return sort; }
            set { sort = value; }
        }

        public string Dosage
        {
            get { return dosage; }
            set { dosage = value; }
        }
    }
}