﻿using System;
using System.Windows.Forms;

namespace ZorgProject
{
    public partial class Form1 : Form
    {
        private static bool doctor = false;
        readonly JsonReader reader = new JsonReader();
        public static bool change = false;

        public Form1()
        {
            InitializeComponent();
            CbBLanguage.SelectedIndex = 0;
        }

        private void BtnPatient_Click(object sender, EventArgs e)
        {
            Doctor = false;
            PatientForm patient1 = new PatientForm();
            patient1.Show();
            Hide();
        }

        public static bool Doctor
        {
            get { return doctor; }
            set { doctor = value; }
        }

        private void BtnDoctor_Click(object sender, EventArgs e)
        {
            Doctor = true;
            PatientForm patient1 = new PatientForm();
            patient1.Show();
            Hide();
        }

        private void CbBLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            BtnPatient.Text = CbBLanguage.SelectedIndex == 0 ? reader.NLList[0] : reader.ENList[0];
            BtnDoctor.Text = CbBLanguage.SelectedIndex == 0 ? reader.NLList[1] : reader.ENList[1];


            change = CbBLanguage.SelectedIndex == 0 ? false : true;
        }
    }
}
