﻿using System;
using System.Windows.Forms;

namespace ZorgProject
{
    public partial class PatientForm : Form
    {
        readonly JsonReader json = new JsonReader();
        readonly Profile profile = new Profile(null, null, 0, 0, 0);
        readonly JsonReader reader = new JsonReader();

        public PatientForm()
        {
            InitializeComponent();
            ChangeLanguage();
            Patient();   
        }

        private void ChangeLanguage()
        {
            BtnBack.Text = Form1.change == false ? reader.NLList[2] : reader.ENList[2];
            BtnMedicine.Text = Form1.change == false ? reader.NLList[3] : reader.ENList[3];
            LblFName.Text = Form1.change == false ? reader.NLList[4] : reader.ENList[4];
            LblLName.Text = Form1.change == false ? reader.NLList[5] : reader.ENList[5];
            LblAge.Text = Form1.change == false ? reader.NLList[6] : reader.ENList[6];
            LblWeight.Text = Form1.change == false ? reader.NLList[7] : reader.ENList[7];
            lblLength.Text = Form1.change == false ? reader.NLList[8] : reader.ENList[8];
            BtnEdit.Text = Form1.change == false ? reader.NLList[9] : reader.ENList[9];
            BtnGraph.Text = Form1.change == false ? reader.NLList[10] : reader.ENList[10];
            LblBMI.Text = Form1.change == false ? reader.NLList[11] : reader.ENList[11];
        }

        private void Doctor()
        {
            if (Form1.Doctor)
            {
                tbFName.ReadOnly = false;
                tbLName.ReadOnly = false;
                tbAge.ReadOnly = false;
                tbWeight.ReadOnly = false;
                tbLenght.ReadOnly = false;
                BtnEdit.Visible = true;
            }
        }

        private void Patient()
        {
            Doctor();

            profile.FName = json.FName;
            profile.LName = json.LName;
            profile.Age = json.Age;
            profile.Weight = json.Weight;
            profile.Lenght = json.Lenght;

            tbFName.Text = profile.FName;
            tbLName.Text = profile.LName;
            tbAge.Text = profile.Age.ToString();
            tbWeight.Text = profile.Weight.ToString();
            tbLenght.Text = profile.Lenght.ToString();
            tbBMI.Text = profile.BMI();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            Hide();
        }

        private void BtnMedicine_Click(object sender, EventArgs e)
        {
            MedicineForm medicine = new MedicineForm();
            medicine.Show();
            Hide();
        }

        private void BtnGraph_Click(object sender, EventArgs e)
        {
            GraphForm graph = new GraphForm();
            graph.Show();
            Hide();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            json.Write(double.Parse(tbWeight.Text));
            profile.FName = tbFName.Text;
            profile.LName = tbLName.Text;
            profile.Age = int.Parse(tbAge.Text);
            profile.Weight = double.Parse(tbWeight.Text);
            profile.Lenght = double.Parse(tbLenght.Text);
            tbBMI.Text = profile.BMI();
        }
    }
}
