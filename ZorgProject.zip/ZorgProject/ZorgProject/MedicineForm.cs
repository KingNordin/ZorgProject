﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ZorgProject
{
    public partial class MedicineForm : Form
    {
        readonly Medicine medicine = new Medicine();
        readonly JsonReader reader = new JsonReader();

        public MedicineForm()
        {
            InitializeComponent();
            Doctor();
            ChangeLanguage();

            CreatMedicineList(reader.namesOfMedicne[0], reader.descriptions[0], reader.dosages[0], reader.sorts[0]);

            for(int i = 0; i < reader.namesOfMedicne.Length; i++)
            {
                AddRow();
                CreateMedicine(DGVMedicine.Rows[i], 0, reader.namesOfMedicne[i]);
                CreateMedicine(DGVMedicine.Rows[i], 1, reader.descriptions[i]);
                CreateMedicine(DGVMedicine.Rows[i], 2, reader.dosages[i]);
                CreateMedicine(DGVMedicine.Rows[i], 3, reader.sorts[i]);
            }     
        }

        private void Doctor()
        {
            if (Form1.Doctor)
            {
                LblMedicineName.Visible = true;
                LblDescription.Visible = true;
                LblDosage.Visible = true;
                LblSort.Visible = true;
                tbMedicineName.Visible = true;
                tbDescription.Visible = true;
                tbDosage.Visible = true;
                tbSort.Visible = true;
                BtnCreateMedicine.Visible = true;
                LblChange.Visible = true;
                tbChange.Visible = true;
                BtnEdit.Visible = true;
            }
        }

        private void ChangeLanguage()
        {
            BtnBack.Text = Form1.change == false ? reader.NLList [2] : reader.ENList [2];
            LblMedicineName.Text = Form1.change == false ? reader.NLList [12] : reader.ENList [12];
            LblDescription.Text = Form1.change == false ? reader.NLList [13] : reader.ENList [13];
            LblDosage.Text = Form1.change == false ? reader.NLList [14] : reader.ENList [14];
            LblSort.Text = Form1.change == false ? reader.NLList [15] : reader.ENList [15];
            BtnCreateMedicine.Text = Form1.change == false ? reader.NLList [16] : reader.ENList [16];
            LblChange.Text = Form1.change == false ? reader.NLList [17] : reader.ENList [17];
            BtnEdit.Text = Form1.change == false ? reader.NLList [9] : reader.ENList [9];

            DGVMedicine.Columns[0].HeaderText = Form1.change == false ? reader.NLList[3] : reader.ENList[3];
            DGVMedicine.Columns[1].HeaderText = Form1.change == false ? reader.NLList[13] : reader.ENList[13];
            DGVMedicine.Columns[2].HeaderText = Form1.change == false ? reader.NLList[14] : reader.ENList[14];
            DGVMedicine.Columns[3].HeaderText = Form1.change == false ? reader.NLList[15] : reader.ENList[15];
        }

        private ArrayList CreatMedicineList(string medicineName, string description, string dosage, string sort)
        {
            medicine.MedicineName = medicineName;
            medicine.Description = description;
            medicine.Dosage = dosage;
            medicine.Sort = sort;

            ArrayList medicineList = new ArrayList
            {
                medicine
            };

            return medicineList;
        }

        private void CreateMedicine(DataGridViewRow row, int columnIndex, string value)
        {
            row.Cells[columnIndex].Value = value;
            row.DataGridView.AutoResizeColumn(columnIndex, DataGridViewAutoSizeColumnMode.DisplayedCells);
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            PatientForm patient = new PatientForm();
            patient.Show();
            Hide();
        }

        private void WriteToFile()
        {
            List<string> medicineNameList = new List<string>();
            List<string> descriptionList = new List<string>();
            List<string> dosageList = new List<string>();
            List<string> sortList = new List<string>();

            for (int i = 0; i < reader.namesOfMedicne.Length; i++)
            {
                medicineNameList.Add(reader.namesOfMedicne[i]);
                descriptionList.Add(reader.descriptions[i]);
                dosageList.Add(reader.dosages[i]);
                sortList.Add(reader.sorts[i]);
            }

            medicineNameList.Add(tbMedicineName.Text);
            descriptionList.Add(tbDescription.Text);
            dosageList.Add(tbDosage.Text);
            sortList.Add(tbSort.Text);

            string[] medicineNames = medicineNameList.ToArray();
            string[] descriptions = descriptionList.ToArray();
            string[] dosages = dosageList.ToArray();
            string[] sorts = sortList.ToArray();

            AddRow();

            reader.WriteMedicine(medicineNames, descriptions, dosages, sorts);
        }

        private void AddRow()
        {
            CreatMedicineList(tbMedicineName.Text, tbDescription.Text, tbDosage.Text, tbSort.Text);
            DGVMedicine.Rows.Add(medicine.MedicineName, medicine.Description, medicine.Dosage, medicine.Sort);
        }

        private void BtnCreateMedicine_Click(object sender, EventArgs e)
        {
            if(tbMedicineName.Text != "" || tbDescription.Text != "" || tbDosage.Text != "" || tbSort.Text != "")
            {
                WriteToFile();
            }
        }

        int index = 0;

        private void DGVMedicine_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DGVMedicine.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                tbChange.Text = DGVMedicine.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                index = e.ColumnIndex;
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            string value = DGVMedicine.Rows[DGVMedicine.CurrentCell.RowIndex].Cells[DGVMedicine.CurrentCell.ColumnIndex].Value.ToString();
            int arrayIndex;

            switch (DGVMedicine.CurrentCell.ColumnIndex)
            {
                case 0:
                    arrayIndex = Array.IndexOf(reader.namesOfMedicne, value);
                    reader.namesOfMedicne[arrayIndex] = tbChange.Text;
                    reader.WriteMedicine(reader.namesOfMedicne, reader.descriptions, reader.dosages, reader.sorts);
                    break;
                case 1:
                    arrayIndex = Array.IndexOf(reader.descriptions, value);
                    reader.descriptions[arrayIndex] = tbChange.Text;
                    reader.WriteMedicine(reader.namesOfMedicne, reader.descriptions, reader.dosages, reader.sorts);
                    break;
                case 2:
                    arrayIndex = Array.IndexOf(reader.dosages, value);
                    reader.dosages[arrayIndex] = tbChange.Text;
                    reader.WriteMedicine(reader.namesOfMedicne, reader.descriptions, reader.dosages, reader.sorts);
                    break;
                case 3:
                    arrayIndex = Array.IndexOf(reader.sorts, value);
                    reader.sorts[arrayIndex] = tbChange.Text;
                    reader.WriteMedicine(reader.namesOfMedicne, reader.descriptions, reader.dosages, reader.sorts);
                    break;
                case -1:
                    MessageBox.Show("No");
                    break;
            }         

            switch (index)
            {
                case 0:
                    medicine.MedicineName = tbChange.Text;
                    CreateMedicine(DGVMedicine.Rows[DGVMedicine.CurrentCell.RowIndex], DGVMedicine.CurrentCell.ColumnIndex, medicine.MedicineName);
                    break;
                case 1:
                    medicine.Description = tbChange.Text;
                    CreateMedicine(DGVMedicine.Rows[DGVMedicine.CurrentCell.RowIndex], DGVMedicine.CurrentCell.ColumnIndex, medicine.Description);
                    break;
                case 2:
                    medicine.Dosage = tbChange.Text;
                    CreateMedicine(DGVMedicine.Rows[DGVMedicine.CurrentCell.RowIndex], DGVMedicine.CurrentCell.ColumnIndex, medicine.Dosage);
                    break;
                case 3:
                    medicine.Sort = tbChange.Text;
                    CreateMedicine(DGVMedicine.Rows[DGVMedicine.CurrentCell.RowIndex], DGVMedicine.CurrentCell.ColumnIndex, medicine.Sort);
                    break;
                default:
                    MessageBox.Show("No");
                    break;
            }
        }
    }
}