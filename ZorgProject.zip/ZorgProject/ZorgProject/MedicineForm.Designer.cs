﻿
namespace ZorgProject
{
    partial class MedicineForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGVMedicine = new System.Windows.Forms.DataGridView();
            this.MedicineColomn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionColomn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DosageColomn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SortColomn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnBack = new System.Windows.Forms.Button();
            this.BtnCreateMedicine = new System.Windows.Forms.Button();
            this.tbMedicineName = new System.Windows.Forms.TextBox();
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.tbDosage = new System.Windows.Forms.TextBox();
            this.tbSort = new System.Windows.Forms.TextBox();
            this.LblMedicineName = new System.Windows.Forms.Label();
            this.LblDescription = new System.Windows.Forms.Label();
            this.LblDosage = new System.Windows.Forms.Label();
            this.LblSort = new System.Windows.Forms.Label();
            this.tbChange = new System.Windows.Forms.TextBox();
            this.LblChange = new System.Windows.Forms.Label();
            this.BtnEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGVMedicine)).BeginInit();
            this.SuspendLayout();
            // 
            // DGVMedicine
            // 
            this.DGVMedicine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVMedicine.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MedicineColomn,
            this.descriptionColomn,
            this.DosageColomn,
            this.SortColomn});
            this.DGVMedicine.Location = new System.Drawing.Point(12, 49);
            this.DGVMedicine.Name = "DGVMedicine";
            this.DGVMedicine.RowHeadersWidth = 51;
            this.DGVMedicine.RowTemplate.Height = 24;
            this.DGVMedicine.Size = new System.Drawing.Size(761, 150);
            this.DGVMedicine.TabIndex = 0;
            this.DGVMedicine.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVMedicine_CellClick);
            // 
            // MedicineColomn
            // 
            this.MedicineColomn.HeaderText = "Medicijn";
            this.MedicineColomn.MinimumWidth = 6;
            this.MedicineColomn.Name = "MedicineColomn";
            this.MedicineColomn.ReadOnly = true;
            this.MedicineColomn.Width = 125;
            // 
            // descriptionColomn
            // 
            this.descriptionColomn.HeaderText = "Omschrijving";
            this.descriptionColomn.MinimumWidth = 6;
            this.descriptionColomn.Name = "descriptionColomn";
            this.descriptionColomn.ReadOnly = true;
            this.descriptionColomn.Width = 125;
            // 
            // DosageColomn
            // 
            this.DosageColomn.HeaderText = "Dosering";
            this.DosageColomn.MinimumWidth = 6;
            this.DosageColomn.Name = "DosageColomn";
            this.DosageColomn.ReadOnly = true;
            this.DosageColomn.Width = 125;
            // 
            // SortColomn
            // 
            this.SortColomn.HeaderText = "Soort";
            this.SortColomn.MinimumWidth = 6;
            this.SortColomn.Name = "SortColomn";
            this.SortColomn.ReadOnly = true;
            this.SortColomn.Width = 125;
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(13, 13);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(75, 30);
            this.BtnBack.TabIndex = 1;
            this.BtnBack.Text = "Terug";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // BtnCreateMedicine
            // 
            this.BtnCreateMedicine.Location = new System.Drawing.Point(12, 347);
            this.BtnCreateMedicine.Name = "BtnCreateMedicine";
            this.BtnCreateMedicine.Size = new System.Drawing.Size(149, 30);
            this.BtnCreateMedicine.TabIndex = 2;
            this.BtnCreateMedicine.Text = "Maak medicijn aan";
            this.BtnCreateMedicine.UseVisualStyleBackColor = true;
            this.BtnCreateMedicine.Visible = false;
            this.BtnCreateMedicine.Click += new System.EventHandler(this.BtnCreateMedicine_Click);
            // 
            // tbMedicineName
            // 
            this.tbMedicineName.Location = new System.Drawing.Point(121, 219);
            this.tbMedicineName.Name = "tbMedicineName";
            this.tbMedicineName.Size = new System.Drawing.Size(100, 22);
            this.tbMedicineName.TabIndex = 3;
            this.tbMedicineName.Visible = false;
            // 
            // tbDescription
            // 
            this.tbDescription.Location = new System.Drawing.Point(121, 255);
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.Size = new System.Drawing.Size(100, 22);
            this.tbDescription.TabIndex = 4;
            this.tbDescription.Visible = false;
            // 
            // tbDosage
            // 
            this.tbDosage.Location = new System.Drawing.Point(121, 289);
            this.tbDosage.Name = "tbDosage";
            this.tbDosage.Size = new System.Drawing.Size(100, 22);
            this.tbDosage.TabIndex = 5;
            this.tbDosage.Visible = false;
            // 
            // tbSort
            // 
            this.tbSort.Location = new System.Drawing.Point(121, 319);
            this.tbSort.Name = "tbSort";
            this.tbSort.Size = new System.Drawing.Size(100, 22);
            this.tbSort.TabIndex = 6;
            this.tbSort.Visible = false;
            // 
            // LblMedicineName
            // 
            this.LblMedicineName.AutoSize = true;
            this.LblMedicineName.Location = new System.Drawing.Point(12, 222);
            this.LblMedicineName.Name = "LblMedicineName";
            this.LblMedicineName.Size = new System.Drawing.Size(102, 17);
            this.LblMedicineName.TabIndex = 7;
            this.LblMedicineName.Text = "Medicijn naam:";
            this.LblMedicineName.Visible = false;
            // 
            // LblDescription
            // 
            this.LblDescription.AutoSize = true;
            this.LblDescription.Location = new System.Drawing.Point(12, 258);
            this.LblDescription.Name = "LblDescription";
            this.LblDescription.Size = new System.Drawing.Size(88, 17);
            this.LblDescription.TabIndex = 8;
            this.LblDescription.Text = "Beschrijving:";
            this.LblDescription.Visible = false;
            // 
            // LblDosage
            // 
            this.LblDosage.AutoSize = true;
            this.LblDosage.Location = new System.Drawing.Point(12, 292);
            this.LblDosage.Name = "LblDosage";
            this.LblDosage.Size = new System.Drawing.Size(69, 17);
            this.LblDosage.TabIndex = 9;
            this.LblDosage.Text = "Dosering:";
            this.LblDosage.Visible = false;
            // 
            // LblSort
            // 
            this.LblSort.AutoSize = true;
            this.LblSort.Location = new System.Drawing.Point(12, 319);
            this.LblSort.Name = "LblSort";
            this.LblSort.Size = new System.Drawing.Size(46, 17);
            this.LblSort.TabIndex = 10;
            this.LblSort.Text = "Soort:";
            this.LblSort.Visible = false;
            // 
            // tbChange
            // 
            this.tbChange.Location = new System.Drawing.Point(340, 301);
            this.tbChange.Name = "tbChange";
            this.tbChange.Size = new System.Drawing.Size(100, 22);
            this.tbChange.TabIndex = 11;
            this.tbChange.Visible = false;
            // 
            // LblChange
            // 
            this.LblChange.AutoSize = true;
            this.LblChange.Location = new System.Drawing.Point(337, 241);
            this.LblChange.Name = "LblChange";
            this.LblChange.Size = new System.Drawing.Size(286, 34);
            this.LblChange.TabIndex = 12;
            this.LblChange.Text = "Om een waarde te veranderen klik er op en \r\nhet zal in de tekst box hieronder ver" +
    "schijnen\r\n";
            this.LblChange.Visible = false;
            // 
            // BtnEdit
            // 
            this.BtnEdit.Location = new System.Drawing.Point(340, 347);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(100, 30);
            this.BtnEdit.TabIndex = 13;
            this.BtnEdit.Text = "Bewerk";
            this.BtnEdit.UseVisualStyleBackColor = true;
            this.BtnEdit.Visible = false;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // MedicineForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 395);
            this.Controls.Add(this.BtnEdit);
            this.Controls.Add(this.LblChange);
            this.Controls.Add(this.tbChange);
            this.Controls.Add(this.LblSort);
            this.Controls.Add(this.LblDosage);
            this.Controls.Add(this.LblDescription);
            this.Controls.Add(this.LblMedicineName);
            this.Controls.Add(this.tbSort);
            this.Controls.Add(this.tbDosage);
            this.Controls.Add(this.tbDescription);
            this.Controls.Add(this.tbMedicineName);
            this.Controls.Add(this.BtnCreateMedicine);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.DGVMedicine);
            this.Name = "MedicineForm";
            this.Text = "MedicineForm";
            ((System.ComponentModel.ISupportInitialize)(this.DGVMedicine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView DGVMedicine;
        private System.Windows.Forms.TextBox tbMedicineName;
        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.TextBox tbDosage;
        private System.Windows.Forms.TextBox tbSort;
        private System.Windows.Forms.DataGridViewTextBoxColumn MedicineColomn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionColomn;
        private System.Windows.Forms.DataGridViewTextBoxColumn DosageColomn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SortColomn;
        private System.Windows.Forms.TextBox tbChange;
        internal System.Windows.Forms.Button BtnBack;
        internal System.Windows.Forms.Button BtnCreateMedicine;
        internal System.Windows.Forms.Label LblMedicineName;
        internal System.Windows.Forms.Label LblDescription;
        internal System.Windows.Forms.Label LblDosage;
        internal System.Windows.Forms.Label LblSort;
        internal System.Windows.Forms.Label LblChange;
        internal System.Windows.Forms.Button BtnEdit;
    }
}