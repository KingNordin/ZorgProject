﻿
namespace ZorgProject
{
    partial class PatientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblFName = new System.Windows.Forms.Label();
            this.LblLName = new System.Windows.Forms.Label();
            this.LblAge = new System.Windows.Forms.Label();
            this.LblWeight = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.LblBMI = new System.Windows.Forms.Label();
            this.tbFName = new System.Windows.Forms.TextBox();
            this.tbLName = new System.Windows.Forms.TextBox();
            this.tbAge = new System.Windows.Forms.TextBox();
            this.tbWeight = new System.Windows.Forms.TextBox();
            this.tbLenght = new System.Windows.Forms.TextBox();
            this.tbBMI = new System.Windows.Forms.TextBox();
            this.BtnBack = new System.Windows.Forms.Button();
            this.BtnMedicine = new System.Windows.Forms.Button();
            this.BtnGraph = new System.Windows.Forms.Button();
            this.BtnEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblFName
            // 
            this.LblFName.AutoSize = true;
            this.LblFName.Location = new System.Drawing.Point(13, 54);
            this.LblFName.Name = "LblFName";
            this.LblFName.Size = new System.Drawing.Size(77, 17);
            this.LblFName.TabIndex = 0;
            this.LblFName.Text = "Voornaam:";
            // 
            // LblLName
            // 
            this.LblLName.AutoSize = true;
            this.LblLName.Location = new System.Drawing.Point(13, 90);
            this.LblLName.Name = "LblLName";
            this.LblLName.Size = new System.Drawing.Size(88, 17);
            this.LblLName.TabIndex = 1;
            this.LblLName.Text = "Achternaam:";
            // 
            // LblAge
            // 
            this.LblAge.AutoSize = true;
            this.LblAge.Location = new System.Drawing.Point(13, 129);
            this.LblAge.Name = "LblAge";
            this.LblAge.Size = new System.Drawing.Size(58, 17);
            this.LblAge.TabIndex = 2;
            this.LblAge.Text = "Leeftijd:";
            // 
            // LblWeight
            // 
            this.LblWeight.AutoSize = true;
            this.LblWeight.Location = new System.Drawing.Point(13, 169);
            this.LblWeight.Name = "LblWeight";
            this.LblWeight.Size = new System.Drawing.Size(62, 17);
            this.LblWeight.TabIndex = 3;
            this.LblWeight.Text = "Gewicht:";
            // 
            // lblLength
            // 
            this.lblLength.AutoSize = true;
            this.lblLength.Location = new System.Drawing.Point(16, 204);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(56, 17);
            this.lblLength.TabIndex = 4;
            this.lblLength.Text = "Lengte:";
            // 
            // LblBMI
            // 
            this.LblBMI.AutoSize = true;
            this.LblBMI.Location = new System.Drawing.Point(19, 241);
            this.LblBMI.Name = "LblBMI";
            this.LblBMI.Size = new System.Drawing.Size(35, 17);
            this.LblBMI.TabIndex = 5;
            this.LblBMI.Text = "BMI:";
            // 
            // tbFName
            // 
            this.tbFName.Location = new System.Drawing.Point(107, 54);
            this.tbFName.Name = "tbFName";
            this.tbFName.ReadOnly = true;
            this.tbFName.Size = new System.Drawing.Size(100, 22);
            this.tbFName.TabIndex = 6;
            // 
            // tbLName
            // 
            this.tbLName.Location = new System.Drawing.Point(107, 90);
            this.tbLName.Name = "tbLName";
            this.tbLName.ReadOnly = true;
            this.tbLName.Size = new System.Drawing.Size(100, 22);
            this.tbLName.TabIndex = 7;
            // 
            // tbAge
            // 
            this.tbAge.Location = new System.Drawing.Point(107, 126);
            this.tbAge.Name = "tbAge";
            this.tbAge.ReadOnly = true;
            this.tbAge.Size = new System.Drawing.Size(100, 22);
            this.tbAge.TabIndex = 8;
            // 
            // tbWeight
            // 
            this.tbWeight.Location = new System.Drawing.Point(107, 166);
            this.tbWeight.Name = "tbWeight";
            this.tbWeight.ReadOnly = true;
            this.tbWeight.Size = new System.Drawing.Size(100, 22);
            this.tbWeight.TabIndex = 9;
            // 
            // tbLenght
            // 
            this.tbLenght.Location = new System.Drawing.Point(107, 204);
            this.tbLenght.Name = "tbLenght";
            this.tbLenght.ReadOnly = true;
            this.tbLenght.Size = new System.Drawing.Size(100, 22);
            this.tbLenght.TabIndex = 10;
            // 
            // tbBMI
            // 
            this.tbBMI.Location = new System.Drawing.Point(107, 241);
            this.tbBMI.Name = "tbBMI";
            this.tbBMI.ReadOnly = true;
            this.tbBMI.Size = new System.Drawing.Size(100, 22);
            this.tbBMI.TabIndex = 11;
            // 
            // BtnBack
            // 
            this.BtnBack.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.BtnBack.Location = new System.Drawing.Point(13, 13);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(75, 28);
            this.BtnBack.TabIndex = 12;
            this.BtnBack.Text = "Terug";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // BtnMedicine
            // 
            this.BtnMedicine.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.BtnMedicine.Location = new System.Drawing.Point(107, 13);
            this.BtnMedicine.Name = "BtnMedicine";
            this.BtnMedicine.Size = new System.Drawing.Size(87, 28);
            this.BtnMedicine.TabIndex = 13;
            this.BtnMedicine.Text = "Medicijnen";
            this.BtnMedicine.UseVisualStyleBackColor = true;
            this.BtnMedicine.Click += new System.EventHandler(this.BtnMedicine_Click);
            // 
            // BtnGraph
            // 
            this.BtnGraph.Location = new System.Drawing.Point(13, 326);
            this.BtnGraph.Name = "BtnGraph";
            this.BtnGraph.Size = new System.Drawing.Size(75, 23);
            this.BtnGraph.TabIndex = 14;
            this.BtnGraph.Text = "Grafiek";
            this.BtnGraph.UseVisualStyleBackColor = true;
            this.BtnGraph.Click += new System.EventHandler(this.BtnGraph_Click);
            // 
            // BtnEdit
            // 
            this.BtnEdit.Location = new System.Drawing.Point(13, 285);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(75, 23);
            this.BtnEdit.TabIndex = 15;
            this.BtnEdit.Text = "Bewerk";
            this.BtnEdit.UseVisualStyleBackColor = true;
            this.BtnEdit.Visible = false;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // PatientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 374);
            this.Controls.Add(this.BtnEdit);
            this.Controls.Add(this.BtnGraph);
            this.Controls.Add(this.BtnMedicine);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.tbBMI);
            this.Controls.Add(this.tbLenght);
            this.Controls.Add(this.tbWeight);
            this.Controls.Add(this.tbAge);
            this.Controls.Add(this.tbLName);
            this.Controls.Add(this.tbFName);
            this.Controls.Add(this.LblBMI);
            this.Controls.Add(this.lblLength);
            this.Controls.Add(this.LblWeight);
            this.Controls.Add(this.LblAge);
            this.Controls.Add(this.LblLName);
            this.Controls.Add(this.LblFName);
            this.Name = "PatientForm";
            this.Text = "PatientForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbFName;
        private System.Windows.Forms.TextBox tbLName;
        private System.Windows.Forms.TextBox tbAge;
        private System.Windows.Forms.TextBox tbWeight;
        private System.Windows.Forms.TextBox tbLenght;
        private System.Windows.Forms.TextBox tbBMI;
        internal System.Windows.Forms.Button BtnBack;
        internal System.Windows.Forms.Button BtnMedicine;
        internal System.Windows.Forms.Label LblFName;
        internal System.Windows.Forms.Label LblLName;
        internal System.Windows.Forms.Label LblAge;
        internal System.Windows.Forms.Label LblWeight;
        internal System.Windows.Forms.Label lblLength;
        internal System.Windows.Forms.Label LblBMI;
        internal System.Windows.Forms.Button BtnGraph;
        internal System.Windows.Forms.Button BtnEdit;
    }
}