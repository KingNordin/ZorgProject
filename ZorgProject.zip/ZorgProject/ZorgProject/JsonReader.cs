﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ZorgProject
{
    class JsonReader : Profile
    {
        public List<string> dates = new List<string>();
        public List<double> weightsList = new List<double>();
        public string[] NLList = { };
        public string[] ENList = { };
        public string[] namesOfMedicne = { };
        public string[] descriptions = { };
        public string[] dosages = { };
        public string[] sorts = { };

        public JsonReader() : base ("", "", 1, 1, 1)
        {
            ReadPatient();
            ReadLanguage();
        }

        private void ReadLanguage()
        {
            string json = File.ReadAllText("Language.json");
            List<Language> items = JsonConvert.DeserializeObject<List<Language>>(json);
            foreach (var item in items)
            {
                NLList = item.NL.Values.ToArray();
                ENList = item.EN.Values.ToArray();
            }
        }

        private void ReadPatient()
        {
            using (StreamReader r = new StreamReader("PatientInfo.json"))
            {
                Dictionary<string, double> weights = new Dictionary<string, double>();
                string json = r.ReadToEnd();
                List<Item> items = JsonConvert.DeserializeObject<List<Item>>(json);
                foreach (var item in items)
                {
                    weights = item.weight;

                    FName = item.firstName;
                    LName = item.lastName;
                    Age = item.age;
                    Lenght = item.length;
                    Weight = weights.Values.Last();
                    namesOfMedicne = item.medicineName;
                    descriptions = item.description;
                    dosages = item.dosage;
                    sorts = item.sort;
                }

                Dictionary<string, double>.KeyCollection keys = weights.Keys;
                weightsList = weights.Values.ToList();

                foreach(string key in keys)
                {
                    dates.Add(key);
                }
            }
        }

        public void Write(double weight)
        {
            string json = File.ReadAllText("PatientInfo.json");
            dynamic jsonObj = JsonConvert.DeserializeObject(json);
            jsonObj[0]["weight"][System.DateTime.Now.ToString("yyyy-M-d")] = weight;
            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText("PatientInfo.json", output);
        }

        public void WriteMedicine(string[] medicineName, string[] description, string[] dosage, string[] sort)
        {
            string json = File.ReadAllText("PatientInfo.json");
            dynamic jsonObj = JsonConvert.DeserializeObject(json);
            jsonObj[0]["medicineName"] = new JArray(medicineName);
            jsonObj[0]["description"] = new JArray(description);
            jsonObj[0]["dosage"] = new JArray(dosage);
            jsonObj[0]["sort"] = new JArray(sort);

            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText("PatientInfo.json", output);
        }

        private class Language
        {
            public Dictionary<string, string> NL;
            public Dictionary<string, string> EN;
        }

        private class Item
        {
            public string firstName;
            public string lastName;
            public string[] dosage;
            public double length;
            public Dictionary<string, double> weight;
            public int age;
            public string[] medicineName;
            public string[] description;
            public string[] sort;
        }
    }
}
