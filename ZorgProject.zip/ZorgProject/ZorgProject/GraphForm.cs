﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Windows.Forms;

namespace ZorgProject
{
    public partial class GraphForm : Form
    {
        readonly JsonReader reader = new JsonReader();

        public GraphForm()
        {
            InitializeComponent();
            ChangeLanguage();
            Graph();
        }

        private void ChangeLanguage()
        {
            BtnBack.Text = Form1.change == false ? reader.NLList[2] : reader.ENList[2];
        }

        private void Graph()
        {
            cartesianChart1.AxisX.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Date",
                Labels = reader.dates
            });

            cartesianChart1.AxisY.Add(new LiveCharts.Wpf.Axis
            {
                Title = "Weight",
                LabelFormatter = value => value.ToString()
            });

            cartesianChart1.LegendLocation = LiveCharts.LegendLocation.Right;

            cartesianChart1.Series.Clear();
            SeriesCollection series = new SeriesCollection();
            series.Add(new LineSeries() { Values = new ChartValues<double>(reader.weightsList) });
            cartesianChart1.Series = series;
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            PatientForm patient = new PatientForm();
            patient.Show();
            Hide();
        }
    }
}